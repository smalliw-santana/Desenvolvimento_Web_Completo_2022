alert('Olá, seja bem vindo ao curso!!!')
document.getElementById("nome").value = 'Oi'